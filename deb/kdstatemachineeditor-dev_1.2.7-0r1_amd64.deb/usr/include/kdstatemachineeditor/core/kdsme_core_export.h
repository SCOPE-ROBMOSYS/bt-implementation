
#ifndef KDSME_CORE_EXPORT_H
#define KDSME_CORE_EXPORT_H

#ifdef KDSME_CORE_STATIC_DEFINE
#  define KDSME_CORE_EXPORT
#  define KDSME_CORE_NO_EXPORT
#else
#  ifndef KDSME_CORE_EXPORT
#    ifdef kdstatemachineeditor_core_EXPORTS
        /* We are building this library */
#      define KDSME_CORE_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KDSME_CORE_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KDSME_CORE_NO_EXPORT
#    define KDSME_CORE_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KDSME_CORE_DEPRECATED
#  define KDSME_CORE_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KDSME_CORE_DEPRECATED_EXPORT
#  define KDSME_CORE_DEPRECATED_EXPORT KDSME_CORE_EXPORT KDSME_CORE_DEPRECATED
#endif

#ifndef KDSME_CORE_DEPRECATED_NO_EXPORT
#  define KDSME_CORE_DEPRECATED_NO_EXPORT KDSME_CORE_NO_EXPORT KDSME_CORE_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KDSME_CORE_NO_DEPRECATED
#    define KDSME_CORE_NO_DEPRECATED
#  endif
#endif

#endif /* KDSME_CORE_EXPORT_H */
