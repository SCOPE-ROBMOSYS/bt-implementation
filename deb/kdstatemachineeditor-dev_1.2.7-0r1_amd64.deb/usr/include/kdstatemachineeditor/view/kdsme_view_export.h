
#ifndef KDSME_VIEW_EXPORT_H
#define KDSME_VIEW_EXPORT_H

#ifdef KDSME_VIEW_STATIC_DEFINE
#  define KDSME_VIEW_EXPORT
#  define KDSME_VIEW_NO_EXPORT
#else
#  ifndef KDSME_VIEW_EXPORT
#    ifdef kdstatemachineeditor_view_EXPORTS
        /* We are building this library */
#      define KDSME_VIEW_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KDSME_VIEW_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KDSME_VIEW_NO_EXPORT
#    define KDSME_VIEW_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KDSME_VIEW_DEPRECATED
#  define KDSME_VIEW_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KDSME_VIEW_DEPRECATED_EXPORT
#  define KDSME_VIEW_DEPRECATED_EXPORT KDSME_VIEW_EXPORT KDSME_VIEW_DEPRECATED
#endif

#ifndef KDSME_VIEW_DEPRECATED_NO_EXPORT
#  define KDSME_VIEW_DEPRECATED_NO_EXPORT KDSME_VIEW_NO_EXPORT KDSME_VIEW_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KDSME_VIEW_NO_DEPRECATED
#    define KDSME_VIEW_NO_DEPRECATED
#  endif
#endif

#endif /* KDSME_VIEW_EXPORT_H */
